import React from 'react'

const Collapse = () => {
  return (
    <div>Collapse</div>
  )
}

export default Collapse