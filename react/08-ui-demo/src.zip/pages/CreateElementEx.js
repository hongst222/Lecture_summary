import React from 'react'

const CreateElementEx = () => {
  return (
    <div>CreateElementEx</div>
  )
}

export default CreateElementEx