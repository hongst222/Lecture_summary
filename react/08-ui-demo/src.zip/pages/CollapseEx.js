import React from 'react'

const CollapseEx = () => {
  return (
    <div>CollapseEx</div>
  )
}

export default CollapseEx;